import products as pd
import order as od
import sys
def menu():
    ans = True

    while ans:


        print('------------------------------------------------------')
        print("""
        1.View Menu
        2.Order
        3.View Orders
        4.Cancel Order
        0.Exit/Quit
        """)

        ans = input("What would you like to do?   ")

        print("-----------------------------------------------------------------------------------------")

        if ans == "1":
            pd.printItems()
        elif ans == "2":
            itemid = int(input("Enter Menu ID"))
            od.addOrder(itemid)
            print("Order Added")

        elif ans == "3":

            od.printOrders()
        elif ans == "4":
            orderid = int(input("Enter Order ID"))
            od.cancelOrder(orderid)
            print("Order Canceled")

        elif ans == "0":
            print("\n System Exited....")
            ans = None
            sys.exit(0)
        else:
            print("\n Not Valid Choice Try again")



if __name__ == '__main__':
    pd.AddItems()
    print('Welcome to restaurant software ordering system')
    print('SELECT MENU OPTION')
    menu()









