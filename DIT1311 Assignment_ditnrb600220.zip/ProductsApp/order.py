import products as pd
# create order class
class Order:
    def __init__(self,orderid,name):
        self.orderid=orderid
        self.name=name




orders=[]

def printOrders():
    print('{}           {}'.format('Order ID', 'Name'))
    for order in orders:
        print('{}                   {}'.format(order.orderid, order.name))


def addOrder(itemCode):
    for product in pd.products:
        if product.productcode==itemCode:
            item = Order(len(orders)+2, product.name)
            orders.append(item)
            break
def cancelOrder(orderid):
    for order in orders:
        if order.orderid==orderid:
            orders.remove(order)
            break





