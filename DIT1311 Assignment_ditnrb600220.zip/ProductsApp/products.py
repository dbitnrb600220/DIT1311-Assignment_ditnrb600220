# create product class
class Product:
    def __init__(self,productcode,name):
        self.productcode=productcode
        self.name=name




products=[]

def printItems():
    print('{}      {}'.format('Product Code', 'Name'))

    for product in products:
        print('{}              {}'.format(product.productcode, product.name))


def AddItems():
    item1 = Product(1001, "CLASSIC OMELETTE ( KSH. 610 )")
    item2 = Product(1002, "EGG WHITE OMELETTE ( KSH. 640 )")
    item3 = Product(1003, "ENGLISH BREAKFAST PLATTER ( KSH. 990 )")
    item4 = Product(1004, "BREAKFAST MIXED GRILL PLATTER ( KSH. 1,100 )")
    item5 = Product(1005, "AVOCADO ON TOAST ( KSH. 640 )")
    item6 = Product(1006, "FRENCH TOAST ( KSH. 750 )")
    item7 = Product(1007, "BREAKFAST PANCAKE ( KSH. 700 )")
    products.append(item1)
    products.append(item2)
    products.append(item3)
    products.append(item4)
    products.append(item5)
    products.append(item6)
    products.append(item7)


